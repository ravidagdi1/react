const router=require('express').Router()
const empc=require('../controllers/empcontroller')
const regc=require('../controllers/regcontroller')
const multer=require('multer')

let storage=multer.diskStorage({
    destination:function(req,file,cb){
        cb(null,'./public/upload')
    },
    filename: function(req,file,cb){
        cb(null,Date.now()+file.originalname)
    }
})

    let upload=multer({
        storage:storage,
        limits:{fileSize:1024*1024*4}
    })

    let mutiple=upload.fields([{name:'img'},{name:'img2'}])

router.post('/empinsert',empc.empinsert)
router.get('/empdata',empc.empdata)
router.get('/singledata/:id',empc.singledata)
router.put('/empupdate/:id',empc.empupdate)
router.delete('/empdelete/:id',empc.empdelete)
router.post('/reg',regc.register)
router.post('/login',regc.login)
router.post('/imageupload',mutiple,(req,res)=>{
    console.log(req.files)
   
})

router.post('/emailsend',upload.single('file'),(req,res)=>{
    console.log(req.body)
    console.log(req.file)
})



module.exports=router