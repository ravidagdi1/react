const Reg=require('../models/reg')


exports.register=async(req,res)=>{
    try{
    const{username,password}=req.body
    const usercheck=await Reg.findOne({username:username})
    if(usercheck===null){
    const record=new Reg({username:username,password:password})
    record.save()
    res.json({
        status:201,
        apiData:record
    })
}else{
    res.json({
        status:400,
        message:'Username is alreay taken'
    })
}
    }catch(error){
        res.json({
            status:400,
            message:error.message
        })
    }
}


exports.login=async(req,res)=>{
    const{username,password}=req.body
    try{
    const record=await Reg.findOne({username:username})
    if(record!==null){
        if(record.password===password){
        res.json({
            status:200,
            apiData:record
        })
    }else{
       res.json({
        status:400,
        message:'Wrong Credentails'

       }) 
    }
    }else{
        res.json({
            status:400,
            message:"Wrong Crdentails"
        })
    }
}catch(error){
    res.json({
        status:400,
        message:error.message
    })
}

}