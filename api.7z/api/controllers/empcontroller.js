const Emp=require('../models/emp')


exports.empinsert=(req,res)=>{
    const{firstName,lastName,email}=req.body
    try{
    const record=new Emp({fname:firstName,lname:lastName,email:email})
    record.save()
    res.json({
        status:201,
        message:'Record has been successfuly inserted',
        apiData:record
    })
    }catch(error){
        res.json({
            status:400,
            message:error.message
        })
    }
   
}


exports.empdata=async(req,res)=>{
    try{
    const record=await Emp.find()
    res.json({
        status:200,
        apiData:record
    })
    }catch(error){
        res.json({
            status:500,
            message:error.message
        })
    }
}


exports.singledata=async(req,res)=>{
    try{
 const id=req.params.id
 const record=await Emp.findById(id)
 res.json({
    status:200,
    apiData:record
 })
    }catch(error){
        res.json({
            status:500,
            message:error.message
        })
    }

}

exports.empupdate=async(req,res)=>{
    try{
    const id=req.params.id
    const{firstName,lastName,email}=req.body
    await Emp.findByIdAndUpdate(id,{fname:firstName,lname:lastName,email:email})
    res.json({
        status:200,
        message:"Successfully Updated"
    })
    }catch(error){
        res.json({
            status:500,
            message:error.message
        })
    }

}

exports.empdelete=async(req,res)=>{
    const id=req.params.id
    try{
    await Emp.findByIdAndDelete(id)
    res.json({
        status:200,
        message:'Successfully Deleted'
    })
    }catch(error){
    res.json({
        status:500,
        message:error.message
    })
    }
}